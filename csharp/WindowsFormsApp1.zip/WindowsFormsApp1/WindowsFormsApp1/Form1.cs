﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int Number = 1;
        private void button1_Click(object sender, EventArgs e)
        
        {
            if (Number == 1)
            {
                label1.Text = "Hello!";
                Number = 0;
            }

            else if (Number == 0)
            {
                label1.Text = "haha";
                Number = 2;
            }

            else if(Number == 2)
            {
                label1.Text = "byebye";
                Number = 1;
            }
        }
 
            
        private void label1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
